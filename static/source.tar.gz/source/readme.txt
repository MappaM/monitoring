Dépendances :

Linux : 
- Python
- Python-mysqldb
- pytz
- yuglify

Python :
- pip install django
- pip install django-mathfilters
- pip install utils
- pip install DjangoFullSerializers
- pip install django-pipeline
- pip install django-extensions
